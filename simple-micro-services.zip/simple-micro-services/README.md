This is simple microservice app 1. frontend service which user can see and can input 2 number and 
2. Add-service it get the 2 numbers from frontend and return the addition
3. subtract-service it get the 2 numbers from frontend and return the substraction

how to run the app at once
  docker-compose up --build



To run separatlty
docker build -t add .
docker build -t subtract .
docker build -t frontend .


docker run -p 3000:3000 subtract
docker run -p 3001:3001 add
docker run -p 3000:80 frontend


