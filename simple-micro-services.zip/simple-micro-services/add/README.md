docker build -t chrisadams1267/add add

docker run -d -p 8081:80 chrisadams1267/add
