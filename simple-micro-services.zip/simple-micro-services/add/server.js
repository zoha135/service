
const express = require('express');
const cors = require('cors');
const app = express();
const port = 3001;

app.use(cors()); // Enable CORS
app.use(express.json());

app.post('/add', (req, res) => {
  const { num1, num2 } = req.body;
  if (isNaN(num1) || isNaN(num2)) {
    return res.status(400).send('Invalid numbers provided');
  }
  const result = parseFloat(num1) + parseFloat(num2);
  res.send(`The result of subtracting ${num2} from ${num1} is ${result}`);
});
app.get('/', (req, res) => {
  res.json({ servicename:" addition" });
});

app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}`);
});
