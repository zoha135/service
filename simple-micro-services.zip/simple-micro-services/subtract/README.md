docker build -t chrisadams1267/subtract subtract

docker run -d -p 8082:80 chrisadams1267/subtract
